<!doctype html>

  <html class="no-js"  <?php language_attributes(); ?>>

	<head>
		<meta charset="utf-8">

		<!-- Force IE to use the latest rendering engine available -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge">

		<!-- Mobile Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta class="foundation-mq">

		<!-- If Site Icon isn't set in customizer -->
		<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) { ?>
			<!-- Icons & Favicons -->
			<?php if (of_get_option( 'fav_icon')) { ?>
				<link rel="icon" type="image/png" href="<?php echo of_get_option('fav_icon'); ?>">
				<link rel="apple-touch-icon" href="<?php echo of_get_option('fav_icon'); ?>" />
				<meta name="msapplication-TileColor" content="#f01d4f">
				<meta name="msapplication-TileImage" content="<?php echo of_get_option('fav_icon'); ?>">
			<?php } ?>	
	    <meta name="theme-color" content="#121212">
	    <?php } ?>

		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
		<?php wp_head(); ?>

		<?php 
			$ga_id = of_get_option('ga_tracking_id');
			if ( !empty( $ga_id ) ) { ?>
				<!-- Google Analytics tracking -->
				<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo ($ga_id); ?>"></script>
				<script>
				  window.dataLayer = window.dataLayer || [];
				  function gtag(){dataLayer.push(arguments);}
				  gtag('js', new Date());

				  gtag('config', '<?php echo ($ga_id); ?>');
				</script>
				<!-- end analytics -->
		<?php } ?>

	</head>

	<body <?php body_class(); ?>>

		<div class="off-canvas-content" data-off-canvas-content>
			<?php if (of_get_option('top_strip_menu_checkbox','1')) { ?>
				<div class="top-strip">
				<?php get_template_part( 'parts/nav', 'topbar-strip' ); ?>
				</div>
			<?php } ?>

			<header class="header" role="banner">
				 <?php get_template_part( 'parts/nav', 'offcanvas-topbar' ); ?>
			</header>

          <div class="large-12 game-overlay" id="games" data-toggler data-animate="fade-in fade-out">
            <?php
              include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
              if (is_plugin_active( 'vegashero/vegashero.php' )) {
                get_template_part( 'parts/games', 'shortcode' );
              }
            ?>
          </div>
