<?php
$games_on_homepage = of_get_option( 'casino_posts', '6');
$args = array('post_type' => 'casino_type', 'posts_per_page' => $games_on_homepage, 'paged' => $paged);
query_posts($args);
?>

<div class="row casino-reviews-grid small-up-1 medium-up-2 large-up-3">

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<div class="column">
			<div class="card" <?php if(of_get_option('casino_terms_link')) { ?> style="min-height: 376px;" <?php } ?>>
				<a class="vh-casino-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					<a href="<?php the_permalink(); ?>" class="vh-casino-overlay">
							<?php
								if ( has_post_thumbnail() ) {
									the_post_thumbnail('vh-casino-thumb');
								} else { ?>
									<a href="<?php the_permalink(); ?>" class="no-image-radius">
										<span><?php $title = get_the_title(); echo $title[0];?></span>
									</a>
							<?php
								}
							?>
					</a>
					<?php
						if (get_field('field_bonus_offer')) { ?>
						<div class="vh-bonus-text">
							<?php echo get_field('field_bonus_offer'); ?>
						</div>
						<?php
						}
					?>
					<div class="grid-casino-rating"><?php if (function_exists('wp_review_show_total')) wp_review_show_total(); ?></div>
					<?php
						if (of_get_option('casino_terms_link') && get_field('casino-terms-link-url')) { ?>
							<a rel="nofollow" href="<?php echo get_field('casino-terms-link-url'); ?>" class="terms-link"><?php echo get_field('casino-terms-link-url-text'); ?></a>
						<?php
						}
					?>
					<a href="<?php if(of_get_option('casino_posts_btn_override')) { echo get_field('field_affiliate_url'); } else { the_permalink(); } ?>" <?php if(of_get_option('casino_posts_btn_override')) { ?>target="_blank" <?php } ?> <?php if (of_get_option('casino_link_nofollow', '0')) { ?>rel="nofollow" <?php } ?> class="button"><?php echo of_get_option( 'casino_posts_btn_text', 'Get Bonus'); ?></a>
			</div>
		</div>


		<?php endwhile; ?>

		<?php joints_page_navi(); ?>

	<?php else : ?>

		<?php echo _e( 'No casinos found', 'vegashero-theme' ); ?>

	<?php endif;

	//wp_reset_query();

	?>

</div>
