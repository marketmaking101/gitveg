<?php if (is_singular('vegashero_games')) { ?>

	<span class="byline">
		<?php if (of_get_option('game_meta_provider', '0')) { 
			$cats = get_the_terms(get_the_ID(), 'game_provider') ?>
			<span class="byline-cat">
			<?php if ( ! empty( $cats ) ) { 
				$entry_cats = '';
				foreach ( $cats as $cat) { $entry_cats .= $cat->name . ', '; }
				$entry_cats = rtrim( $entry_cats, ', ' );
				echo $entry_cats; }
			?>
			</span>
		<?php } ?>
		<?php if (of_get_option('game_meta_date', '1')) { ?><span class="byline-date"><?php echo get_the_date(); ?></span><?php } ?>
		<?php if (of_get_option('game_meta_author', '1')) { ?><i><?=_e( 'by', 'vegashero-theme' );?> </i><span class="byline-author"><?php the_author(); ?></span><?php } ?>
	</span>

<?php } else { ?>
		
	<span class="byline">

	<?php if (is_singular('casino_type')) { ?>

		<?php if (of_get_option('casino_meta_category', '1')) { 
			$cats = get_the_terms(get_the_ID(), 'casino_category') ?>			
			<span class="byline-cat">
			<?php if ( ! empty( $cats ) ) { 
				$entry_cats = '';
				foreach ( $cats as $cat) { $entry_cats .= $cat->name . ', '; }
				$entry_cats = rtrim( $entry_cats, ', ' );
				echo $entry_cats; } 
			?>				
			</span>
		<?php } ?>
		<?php if (of_get_option('casino_meta_date', '1')) { ?><span class="byline-date"><?php echo get_the_date(); ?></span><?php } ?>
		<?php if (of_get_option('casino_meta_author', '1')) { ?><i><?=_e( 'by', 'vegashero-theme' );?> </i><span class="byline-author"><?php the_author(); ?></span><?php } ?>

	<?php } else { ?>
		<?php if (of_get_option('post_meta_category', '1')) { ?><span class="byline-cat"><?php the_category(', '); ?></span><?php } ?>
		<?php if (of_get_option('post_meta_date', '1')) { ?><span class="byline-date"><?php echo get_the_date(); ?></span><?php } ?>
		<?php if (of_get_option('post_meta_author', '1')) { ?><i><?=_e( 'by', 'vegashero-theme' );?> </i><span class="byline-author"><?php the_author(); ?></span><?php } ?>
	<?php } ?>
	
	</span>

<?php } ?>
