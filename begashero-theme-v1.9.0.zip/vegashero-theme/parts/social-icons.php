<ul class="social-icons">
  <?php if ( of_get_option( 'facebook' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'facebook' ); ?>" class="mdi mdi-facebook-box"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'twitter' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'twitter' ); ?>" class="mdi mdi-twitter-box"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'pinterest' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'pinterest' ); ?>" class="mdi mdi-pinterest-box"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'instagram' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'instagram' ); ?>" class="mdi mdi-instagram"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'linkedin' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'linkedin' ); ?>" class="mdi mdi-linkedin-box"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'tumblr' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'tumblr' ); ?>" class="mdi mdi-tumblr"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'rss' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'rss' ); ?>" class="mdi mdi-rss-box"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'reddit' ) ) { ?>
  <li class="reddit-icon"><a href="<?php echo of_get_option( 'reddit' ); ?>" class="mdi mdi-reddit"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'youtube' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'youtube' ); ?>" class="mdi mdi-youtube-play"></a></li>
  <?php } ?>
  <?php if ( of_get_option( 'twitch' ) ) { ?>
  <li><a href="<?php echo of_get_option( 'twitch' ); ?>" class="mdi mdi-twitch"></a></li>
  <?php } ?>
</ul>
