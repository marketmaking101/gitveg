<div class="top-bar" id="top-bar-menu">
	<div class="row">
		<div class="top-bar-left">
			<ul class="menu">
				<li class="menu-text"><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></li>
			</ul>
		</div>
		<div class="top-bar-right">
			<ul class="menu">
				<li><button class="menu-icon" type="button" data-toggle="off-canvas"></button></li>
				<ul>
					<?php joints_top_nav(); ?>
				</ul>
				<li><a data-toggle="off-canvas"><?php _e( 'Menu', 'vegashero-theme' ); ?></a></li>
			</ul>
		</div>
	</div>
</div>
