<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 */
function optionsframework_option_name() {
	// Change this to use your theme slug
	return 'options-framework-theme';
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'vegashero-theme'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
 */

function optionsframework_options() {

	// Lobby thumb options
	$lobby_thumb_sizes = array(
		'50' => __( 'Half width'),
		'100' => __( 'Full width')
	);
	// Layout data
	$layout_array = array(
		'50' => __( '50%'),
		'70' => __( '70%')
	);

	// Style options
	$options_review_style = array(
		'dark' => __( 'Dark'),
		'light' => __( 'Light')
	);

	// Multicheck Array
	$multicheck_array = array(
		'one' => __( 'French Toast'),
		'two' => __( 'Pancake'),
		'three' => __( 'Omelette'),
		'four' => __( 'Crepe'),
		'five' => __( 'Waffle')
	);

	// Multicheck Defaults
	$multicheck_defaults = array(
		'one' => '1',
		'five' => '1'
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment'=>'scroll' );

	// Typography Defaults
	$typography_defaults = array(
		'size' => '15px',
		'face' => 'georgia',
		'style' => 'bold',
		'color' => '#bada55' );

	// Typography Options
	$typography_options = array(
		'sizes' => array( '6','12','14','16','20' ),
		'faces' => array( 'Helvetica Neue' => 'Helvetica Neue','Arial' => 'Arial' ),
		'styles' => array( 'normal' => 'Normal','bold' => 'Bold' ),
		'color' => false
	);

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all tags into an array
	$options_tags = array();
	$options_tags_obj = get_tags();
	foreach ( $options_tags_obj as $tag ) {
		$options_tags[$tag->term_id] = $tag->name;
	}


	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages( 'sort_column=post_parent,menu_order' );
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}

	// If using image radio buttons, define a directory path
	$imagepath =  get_template_directory_uri() . '/options-framework/images/';

	$options = array();

	//************* GLOBAL SETTINGS *************//

	$options[] = array(
		'name' => __( 'Global Settings'),
		'type' => 'heading'
	);

	// Logo image
	$options[] = array(
		'name' => __( 'Logo image'),
		'desc' => __( 'Upload logo image'),
		'id' => 'logo_image',
		'type' => 'upload'
	);
	// Logo icon
	$options[] = array(
		'name' => __( 'Logo icon'),
		'desc' => __( 'Upload logo icon, appears next to the logo'),
		'id' => 'logo_icon',
		'type' => 'upload'
	);

	// Favicon image
	$options[] = array(
		'name' => __( 'Favicon image'),
		'desc' => __( 'We recommend a 512×512 pixel PNG image'),
		'id' => 'fav_icon',
		'type' => 'upload'
	);

	// Logo top margin
	$options[] = array(
		'name' => __( 'Logo top margin (in pixels)'),
		'id' => 'logo_top_margin',
		'std' => '',
		'class' => 'mini',
		'type' => 'text'
	);

	// Logo bottom margin
	$options[] = array(
		'name' => __( 'Logo bottom margin (in pixels)'),
		'id' => 'logo_bottom_margin',
		'std' => '',
		'class' => 'mini',
		'type' => 'text'
	);

	// Menu top margin
	$options[] = array(
		'name' => __( 'Menu top margin (in pixels)'),
		'id' => 'menu_top_margin',
		'std' => '',
		'class' => 'mini',
		'type' => 'text'
	);

	// top strip menu toggle
	$options[] = array(
		'name' => __( 'Enable / Disable Top Strip Menu (including social icons)'),
		'desc' => sprintf( __('You can choose to display Show / Hide the Top Strip Menu and social links.') ),
		'id' => 'top_strip_menu_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);

	// top games nav toggle
	$options[] = array(	
		'name' => __( 'Enable / Disable Top Games Nav'),
		'desc' => sprintf( __('You can choose to display / hide the Top Right Games Nav.') ),
		'id' => 'top_games_menu_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);

	// top games nav games config
	$options[] = array(
		'name' => __( 'Add Games Grid shortcode for Top Games Nav'),
		'desc' => sprintf( __( 'You can control what games are displayed in the Top Right Games Nav. See shortcode instructions <a href="%1$s" target="_blank">here</a>'), 'https://vegashero.co/shortcode-to-display-games-from-individual-providers-operators-category-or-keyword/' ),
		'id' => 'top_games_menu_shortcode',
		'std' => '[vh-grid category="video slots" orderby="date" order="DESC" gamesperpage="5"]',
		'type' => 'text'
	);

	// toogle title banner strip globally
	$options[] = array(
		'name' => __( 'Show title banner strip on posts, pages, games and casino reviews'),
		'desc' => sprintf( __('You can choose to display the H2 additional title with a background strip above the post / page content') ),
		'id' => 'title_banner_strip_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);

	// Google Analytics tracking
	$options[] = array(
		'name' => __( 'Google Analytics tracking ID'),
		'desc' => __( 'Add your GA property ID here in this format: UA-xxxxxxx-xx'),
		'id' => 'ga_tracking_id',
		'std' => '',
		'class' => 'mini',
		'type' => 'text'
	);

	// Post Meta settings
	$options[] = array(
		'name' => __( 'Post Meta Display Options'),
		'id' => 'post_meta_options',
		'type' => 'info'
	);

	$options[] = array(
		'desc' => sprintf( __( 'Show Single and Archive post category') ),
		'id' => 'post_meta_category',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Single and Archive post date') ),
		'id' => 'post_meta_date',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Single and Archive post author') ),
		'id' => 'post_meta_author',
		'std' => '1',
		'type' => 'checkbox'
	);

	// Footer settings
	$options[] = array(
		'name' => __( 'Footer Display Options'),
		'desc' => sprintf( __( 'Show / Hide whole footer strip') ),
		'id' => 'footer_strip',
		'std' => '1',
		'type' => 'checkbox'
	);

	$options[] = array(
		'desc' => sprintf( __( 'Show footer branding') ),
		'id' => 'footer_branding',
		'std' => '1',
		'type' => 'checkbox'
	);

	$options[] = array(
		'desc' => sprintf( __( 'Show footer social icons') ),
		'id' => 'footer_social',
		'std' => '1',
		'type' => 'checkbox'
	);

	//************* END GLOBAL SETTINGS *************//


	//************* HOMEPAGE SETTINGS *************//

	$options[] = array(
		'name' => __( 'Homepage Settings'),
		'type' => 'heading'
	);

	// Show Full width section
	$options[] = array(
		'name' => __( 'Show Homepage full width content section'),
		'desc' => __( 'Display homepage page content in a full-width area, works with Gutenberg blocks or other page builder'),
		'id' => 'enable_home_content',
		'std' => '0',
		'type' => 'checkbox'
	);

	// Home page width settings
	$options[] = array(
		'name' => __( 'Homepage width setup'),
		'desc' => __( 'Choose a width option for the homepage main column.'),
		'id' => 'homepage_size',
		'std' => '70',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $layout_array
	);

	// toggle news post section
	$options[] = array(	
		'name' => __( 'Show / Hide Homepage news posts section'),
		'desc' => sprintf( __('You can choose to display / hide posts section on the Homepage.') ),
		'id' => 'homepage_posts_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);

	// Display posts from specific categories only
	$options[] = array(
		'name' => __( 'Display posts from only specific categories in homepage posts section'),
		'desc' => __( 'Add individual category IDs here separated by comma. Example: 2, 4, 11. Leave empty to display latest posts from all categories.'),
		'id' => 'homepage_posts_specific_cat',
		'std' => '',
		'class' => 'mini',
		'type' => 'text'
	);

	// Text for posts title homepage
	$options[] = array(
		'name' => __( 'Title for posts section'),
		'id' => 'homepage_posts_title_text',
		'std' => 'Latest news',
		'class' => 'mini',
		'type' => 'text'
	);

	// Number of posts to display on homepage
	$options[] = array(
		'name' => __( 'Number of posts'),
		'id' => 'home_posts',
		'std' => '5',
		'class' => 'mini',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Show Homepage post dates'),
		'desc' => sprintf( __( 'Show date meta info on Homepage post list') ),
		'id' => 'homepost_meta_date',
		'std' => '1',
		'type' => 'checkbox'
	);

	// Button for posts on homepage
	$options[] = array(
		'name' => __( 'Customize "More news" button'),
		'desc' => __( 'Set custom text for this button and pick a specific category below to link it to. If unchecked, the button will link to your default blog posts page that is set under WP Setting / Reading: Posts page'),
		'id' => 'display_all_posts_button_checkbox',
		'std' => '0',
		'type' => 'checkbox'
	);

	// Button text for posts button on homepage
	$options[] = array(
		'name' => __( 'Button text for "More news" button'),
		'id' => 'display_all_posts_button_text',
		'std' => 'More news',
		'class' => 'hidden',
		'type' => 'text'
	);

	if ( $options_categories ) {
		$options[] = array(
			'name' => __( 'Select a Category archive page where the button will link'),
			'desc' => __( 'Your "More news" button will link to this category archives page which will display all posts for this category'),
			'id' => 'news_select_categories',
			'std' => '1',
			'class' => 'hidden',
			'type' => 'select',
			'options' => $options_categories
		);
	}

	// Title for Archives page
	$options[] = array(
		'name' => __( 'Text title for archive page in top banner'),
		'id' => 'archive_title_text',
		'std' => 'All News',
		'class' => 'mini',
		'type' => 'text'
	);

	// Button for games to show on homepage
	// $options[] = array(
	// 	'name' => __( 'Display "More games" button'),
	// 	'id' => 'display_all_games_button_checkbox',
	// 	'std' => '1',
	// 	'type' => 'checkbox'
	// );
	// Button text for games button on homepage
	// $options[] = array(
	// 	'name' => __( 'Button text for "More games" button'),
	// 	'id' => 'display_all_games_button_text',
	// 	'std' => 'More games',
	// 	'class' => 'mini',
	// 	'type' => 'text'
	// );

	// banner image
	$options[] = array(
		'name' => __( 'Home Bottom Banner'),
		'desc' => __( 'Banner area below the posts.'),
		'id' => 'banner_area',
		'type' => 'upload'
	);

	// banner link
	$options[] = array(
		'name' => __( 'Link for banner'),
		'id' => 'banner_area_link',
		'type' => 'text'
	);

	//************* END HOMEPAGE SETTINGS *************//

	//************* BANNER SETTINGS *************//

	$options[] = array(
		'name' => __( 'Banner Settings'),
		'type' => 'heading'
	);

	// enable / disable Main banner/slider
	$options[] = array(
		'name' => __( 'Enable / Disable Home page banner / slider'),
		'desc' => sprintf( __('You can choose to display / hide the Main banner or LayerSlider area on the home page.') ),
		'id' => 'enable_banner_slider',
		'std' => '1',
		'type' => 'checkbox'
	);

	// Slider shortcode
	$options[] = array(
		'name' => __( 'Add your LayerSlider shortcode (overrides Main Banner below)'),
		'desc' => sprintf( __( 'Create your slider here <a href="%1$s" target="_blank">here</a>'), 'admin.php?page=layerslider' ),
		'id' => 'layerslider',
		'std' => '',
		'type' => 'text'
	);

	// Homepage banner image
	$options[] = array(
		'name' => __( 'Main Static Banner'),
		'desc' => __( 'Banner to show on homepage if no LayerSlider is active'),
		'id' => 'homepage_banner',
		'type' => 'upload'
	);

	$options[] = array(
		'name' => __( 'Banner large title'),
		'id' => 'banner_large_title',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Banner description title'),
		'id' => 'banner_description_title',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Banner button title'),
		'id' => 'banner_button_title',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Banner button link'),
		'id' => 'banner_button_link',
		'std' => 'http://',
		'type' => 'text'
	);


	// $options[] = array(
	// 	'name' => __( 'Banner Textarea'),
	// 	'desc' => __( 'Banner Textarea.'),
	// 	'id' => 'homepage_banner_html',
	// 	'std' => 'Default Text',
	// 	'type' => 'textarea'
	// );


	//************* END BANNER SETTINGS *************//

	//************* SOCIAL NETWORKING SETTINGS *************//

	$options[] = array(
		'name' => __( 'Social Settings'),
		'type' => 'heading'
	);

	$options[] = array(
		'name' => __( 'Facebook link'),
		'id' => 'facebook',
		'std' => 'https://www.facebook.com/VegasHeroPlugin/',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Twitter link'),
		'id' => 'twitter',
		'std' => 'https://twitter.com/Vegas_Hero',
		'type' => 'text'
	);

	// $options[] = array(
	// 	'name' => __( 'Google link'),
	// 	'id' => 'google',
	// 	'std' => '',
	// 	'type' => 'text'
	// );	

	$options[] = array(
		'name' => __( 'Pinterest link'),
		'id' => 'pinterest',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Instagram link'),
		'id' => 'instagram',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Linkedin link'),
		'id' => 'linkedin',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Reddit link'),
		'id' => 'reddit',	
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Youtube link'),
		'id' => 'youtube',
		'std' => 'https://www.youtube.com/channel/UCyATnW9Owi6u9al237gpu6Q',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Twitch link'),
		'id' => 'twitch',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Tumblr link'),
		'id' => 'tumblr',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'RSS link'),
		'id' => 'rss',
		'std' => '',
		'type' => 'text'
	);

	//************* END SOCIAL NETWORKING SETTINGS *************//


	//************* GAME PAGE SETTINGS *************//

	$options[] = array(
		'name' => __( 'Game Page Settings'),
		'type' => 'heading'
	);
	$options[] = array(
		'name' => __( 'Enable Global Affiliate button (This will overwrite the mini table on every game post)'),
		'desc' => sprintf( __('This will add a large button link on the right sidebar of all game pages.') ),
		'id' => 'global_link_checkbox',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Global Affiliate button text'),
		'id' => 'global_affiliate_link_text',
		'std' => 'Play for real',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Global Affiliate button link'),
		'id' => 'global_affiliate_link',
		'std' => '',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Display Tablepress mini table (Only shows if Global Affiliate button is disabled)'),
		'desc' => sprintf( __('Show Mini dropdown table + button on the right sidebar of all game pages. Outputs TablePress shortcode content set below.') ),
		'id' => 'mini_table_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'name' => __( 'Mini dropdown table button text'),
		'desc' => sprintf( __('Large button with dropdown option displayed on the right sidebar of games. Dropdown table can be set below via shortcode (TablePress only).') ),
		'id' => 'play_now_text',
		'std' => 'Visit Casino',
		'type' => 'text'
	);
	$options[] = array(
		'name' => __( 'Title for TablePress table (displayed below games)'),
		'desc' => sprintf( __('This is displayed below the games (you can also use the VegasHero Single Games Widget Area for displaying tables under each game)') ),
		'id' => 'bonus_table_title',
		'std' => '',
		'type' => 'text'
	);
	$options[] = array(
		'name' => __( 'Add your TablePress shortcode to all game pages'),
		'desc' => sprintf( __( 'This is displayed below the games AND on the right hand side in the Mini dropdown table as well. Configure your TablePress table <a href="%1$s" target="_blank">here</a>'), 'admin.php?page=tablepress' ),
		'id' => 'bonus_table',
		'std' => '',
		'placeholder' => '[table id=1 /]',
		'type' => 'text'
	);
	
	$options[] = array(
		'name' => __( 'Game excerpt title in sidebar'),
		'desc' => sprintf( __('This is displayed on the right sidebar of games posts. The excerpt area will only show if the game post excerpt field is not empty.') ),
		'id' => 'game_excerpt_title',
		'std' => 'Game Details',
		'type' => 'text'
	);
	$options[] = array(
		'name' => __( 'Display review stars in sidebar'),
		'desc' => sprintf( __('Display the star reviews above button (When WP-Reviews star ratings are configured)') ),
		'id' => 'display_review_stars_checkbox',
		'std' => '0',
		'type' => 'checkbox'
	);
	$options[] = array(
		'name' => __( 'Enable sticky mobile CTA button'),
		'desc' => sprintf( __('This will make the global affiliate link button and the mini-table dropdown button always display on the bottom of mobile screens') ),
		'id' => 'sticky_mobile_affiliate_link_checkbox',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Game Post Meta Display Options'),
		'id' => 'game_meta_options',
		'type' => 'info'
	);

	$options[] = array(
		'desc' => sprintf( __( 'Show Game post provider') ),
		'id' => 'game_meta_provider',
		'std' => '0',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Game post date') ),
		'id' => 'game_meta_date',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Game post author') ),
		'id' => 'game_meta_author',
		'std' => '1',
		'type' => 'checkbox'
	);


	//************* END GAME PAGE SETTINGS *************//

	//************* CASINO PAGE SETTINGS *************//

	$options[] = array(
		'name' => __( 'Casino Page Settings'),
		'type' => 'heading'
	);

	$options[] = array(
		'name' => __( 'Open casino affiliate link in new browser window?'),
		'desc' => sprintf( __('If checked the Visit Casino button and the link on the top of the review panel will open in new window') ),
		'id' => 'casino_link_target_checkbox',
		'std' => '1',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Enable No Follow on affiliate links'),
		'desc' => sprintf( __('Enables rel=nofollow attribute on links on game and bookmaker review posts') ),
		'id' => 'casino_link_nofollow',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Enable sticky mobile CTA button'),
		'desc' => sprintf( __('This will make the casino link button always display on the bottom of mobile screens') ),
		'id' => 'sticky_mobile_casino_link_checkbox',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Override the Casino post button to become your affiliate link'),
		'desc' => sprintf( __('If checked the Casino post button on the casino post cards will link your affiliate link directly and open the promote casino link in a new window. The rest of the casino card will still link to the casino review post.') ),
		'id' => 'casino_posts_btn_override',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Display Terms & Conditions Link'),
		'desc' => sprintf( __('Show Terms and Conditions link on casino cards and casino review posts') ),
		'id' => 'casino_terms_link',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Visit Casino button text'),
		'desc' => sprintf( __('Large button displayed on the right sidebar of the casino reviews post page') ),
		'id' => 'casino_title_button',
		'std' => 'Visit Casino',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Casino card button text'),
		'desc' => sprintf( __('Set the button text that displays on the casino post cards') ),
		'id' => 'casino_posts_btn_text',
		'std' => 'Get Bonus',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Casino excerpt title'),
		'desc' => sprintf( __('Title for excerpt section which is displayed on the right sidebar of casino posts (shows only if excerpt is not blank)') ),
		'id' => 'casino_excerpt_title',
		'std' => 'Casino Details',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Number of casinos to display on casinos main page'),
		'desc' => sprintf( __('Number of casinos to display on the casinos main index page. We recommend the number to be multiples of 3 (example 3/6/9 etc) as the layout is set to 3 columns. (the rest will be paginated)') ),
		'id' => 'casino_posts',
		'std' => '6',
		'class' => 'mini',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Display casino posts on top'),
		'desc' => sprintf( __('If checked the casino post cards will display on top of the index page and the page text will be below them') ),
		'id' => 'casino_posts_ontop',
		'std' => '0',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => __( 'Casino Custom Post Type URL slug'),
		'desc' => sprintf( __('You can set the path for the Casino post URLs here. Example www.yoursite.com/<b>casinos</b>/casino-name/. This CANNOT be the same as your main casinos index page URL!') ),
		'id' => 'casino_cpt_slug',
		'std' => 'casinos',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Casino Category custom URL slug'),
		'desc' => sprintf( __('You can set the base path for the Casino Category URLs here. Example www.yoursite.com/<b>casino-category</b>/category-name/. This CANNOT be the same as the above Casino Custom Post Type URL slug!') ),
		'id' => 'casino_cat_slug',
		'std' => 'casino-category',
		'type' => 'text'
	);

	$options[] = array(
		'name' => __( 'Casino Post Meta Display Options'),
		'id' => 'casino_meta_options',
		'type' => 'info'
	);

	$options[] = array(
		'desc' => sprintf( __( 'Show Casino post category') ),
		'id' => 'casino_meta_category',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Casino post date') ),
		'id' => 'casino_meta_date',
		'std' => '1',
		'type' => 'checkbox'
	);
	$options[] = array(
		'desc' => sprintf( __( 'Show Casino post author') ),
		'id' => 'casino_meta_author',
		'std' => '1',
		'type' => 'checkbox'
	);


	//************* END CASINO PAGE SETTINGS *************//



	//************* STYLING AND COLORS SETTINGS *************//

	$options[] = array(
		'name' => __( 'Styling & Color Settings'),
		'type' => 'heading'
	);

	// $options[] = array(
	// 	'name' => __( 'Disable theme styling for WP review block'),
	// 	'desc' => sprintf( __('Disabling the theme styling for WP review block reverts to default colors of the plugin (gold stars).') ),
	// 	'id' => 'review_style_disable',
	// 	'std' => '0',
	// 	'type' => 'checkbox'
	// );

	if ( $options_review_style ) {
		$options[] = array(
			'name' => __( 'Select a Style for the WP review block'),
			'id' => 'review_style_select',
			'type' => 'select',
			'options' => $options_review_style
		);
	}

	$options[] = array(
		'name' => __( 'Review Star color'),
		'desc' => __( ''),
		'id' => 'review_stars_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Review Star background color'),
		'desc' => __( ''),
		'id' => 'review_stars_bg_color',
		'std' => '',
		'type' => 'color'
	);

	// Site global colors
	// $options[] = array(
	// 	'name' => __( 'Site wrapper background color'),
	// 	'desc' => __( ''),
	// 	'id' => 'site_background_color',
	// 	'std' => '',
	// 	'type' => 'color'
	// );

	// $options[] = array(
	// 	'name' =>  __( 'Site wrapper background color'),
	// 	'desc' => __( 'Choose a background image to the site.'),
	// 	'id' => 'example_background',
	// 	'std' => $background_defaults,
	// 	'type' => 'background'
	// );

	// $options[] = array(
	// 	'name' => __( 'Content background color'),
	// 	'desc' => __( ''),
	// 	'id' => 'content_background_color',
	// 	'std' => '',
	// 	'type' => 'color'
	// );

	// Header, menu colors
	$options[] = array(
		'name' => __( 'Site Header background color'),
		'desc' => __( ''),
		'id' => 'site_header_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Site title color'),
		'desc' => __( ''),
		'id' => 'site_title_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Site subtitle color'),
		'desc' => __( ''),
		'id' => 'site_subtitle_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Menu link color'),
		'desc' => __( ''),
		'id' => 'menu_link_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Menu link hover color'),
		'desc' => __( ''),
		'id' => 'menu_link_hover_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Burger menu icon color'),
		'desc' => __( ''),
		'id' => 'burger_menu_link_color',
		'std' => '',
		'type' => 'color'
	);

	// Table, button colors

	// $options[] = array(
	// 	'name' => __( 'TABLE COLORS'),
	// 	'type' => 'info'
	// );

	$options[] = array(
		'name' => __( 'Table header background color'),
		'desc' => __( ''),
		'id' => 'table_header_bg_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table header text color'),
		'desc' => __( ''),
		'id' => 'table_header_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table odd row background color'),
		'desc' => __( ''),
		'id' => 'table_odd_row_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table odd row text color'),
		'desc' => __( ''),
		'id' => 'table_odd_row_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table even row background color'),
		'desc' => __( ''),
		'id' => 'table_even_row_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table even row text color'),
		'desc' => __( ''),
		'id' => 'table_even_row_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table button color'),
		'desc' => __( ''),
		'id' => 'table_button_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table button hover background color'),
		'desc' => __( ''),
		'id' => 'table_button_hover_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Table button hover text color'),
		'desc' => __( ''),
		'id' => 'table_button_hover_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'General buttons color'),
		'desc' => __( ''),
		'id' => 'general_button_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'General buttons text color'),
		'desc' => __( ''),
		'id' => 'general_button_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'General buttons hover color'),
		'desc' => __( ''),
		'id' => 'general_button_hover_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'General buttons hover text color'),
		'desc' => __( ''),
		'id' => 'general_button_hover_text_color',
		'std' => '',
		'type' => 'color'
	);

	// Games colors
	$options[] = array(
		'name' => __( 'Games grid/lobby item background color'),
		'desc' => __( ''),
		'id' => 'games_item_bg_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Games grid/lobby item text color'),
		'desc' => __( ''),
		'id' => 'games_item_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Games lobby item button color'),
		'desc' => __( ''),
		'id' => 'games_btn_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Games lobby item button text color'),
		'desc' => __( ''),
		'id' => 'games_btn_text_color',
		'std' => '',
		'type' => 'color'
	);

	// casino card colors
	$options[] = array(
		'name' => __( 'Casino card background color'),
		'desc' => __( ''),
		'id' => 'casino_card_bg_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Casino card title color'),
		'desc' => __( ''),
		'id' => 'casino_card_title_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Casino card text color'),
		'desc' => __( ''),
		'id' => 'casino_card_text_color',
		'std' => '',
		'type' => 'color'
	);

	// Content colors

	$options[] = array(
		'name' => __( 'Content & Sidebar widget text color'),
		'desc' => __( ''),
		'id' => 'content_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content & Sidebar widget link color'),
		'desc' => __( ''),
		'id' => 'content_link_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content & Sidebar widget link hover color'),
		'desc' => __( ''),
		'id' => 'content_link_hover_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content & Sidebar widget H1,H2,H3,H4 title colors'),
		'desc' => __( ''),
		'id' => 'content_headers_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content meta, blockquote, secondary headers color'),
		'desc' => __( ''),
		'id' => 'content_meta_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content banner strip default background color'),
		'desc' => __( ''),
		'id' => 'content_bannerstrip_bg_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Content banner strip text color'),
		'desc' => __( ''),
		'id' => 'content_bannerstrip_text_color',
		'std' => '',
		'type' => 'color'
	);

	// Footer colors
	$options[] = array(
		'name' => __( 'Footer background color'),
		'desc' => __( ''),
		'id' => 'footer_bg_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Footer text color'),
		'desc' => __( ''),
		'id' => 'footer_text_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Footer link color'),
		'desc' => __( ''),
		'id' => 'footer_link_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Footer strip background color'),
		'desc' => __( ''),
		'id' => 'footer_strip_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Footer strip link color'),
		'desc' => __( ''),
		'id' => 'footer_strip_link_color',
		'std' => '',
		'type' => 'color'
	);

	// top header strip
	$options[] = array(
		'name' => __( 'Top Strip Menu background color'),
		'desc' => __( ''),
		'id' => 'top_strip_color',
		'std' => '',
		'type' => 'color'
	);

	$options[] = array(
		'name' => __( 'Top Strip Menu link color'),
		'desc' => __( ''),
		'id' => 'top_strip_link_color',
		'std' => '',
		'type' => 'color'
	);



	//************* END STYLING AND COLORS SETTINGS *************//



	return $options;
}


/** Output CSS **/

function theme_get_custom_css() {
ob_start();

?>


<?php if ( of_get_option( 'site_background_color' )) { ?>
	.off-canvas-content {background: <?php echo of_get_option( 'site_background_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'site_title_color' )) { ?>
.logo-wrapper .logo a, .footer .footer-strip .logo-footer { color: <?php echo of_get_option( 'site_title_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'site_subtitle_color' )) { ?>
.logo-wrapper .site-description, .footer .footer-strip .logo-footer span { color: <?php echo of_get_option( 'site_subtitle_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'logo_top_margin' )) { ?>
.logo-wrapper .logo-image, .logo-wrapper .logo { margin-top: <?php echo of_get_option( 'logo_top_margin'); ?>px;}
@media (max-width: 1024px) {
	.header .top-bar#top-bar-menu .row .top-bar-left .logo-image {
		margin-top: <?php echo of_get_option( 'logo_top_margin'); ?>px;
	}
}
<?php } ?>

<?php if ( of_get_option( 'logo_bottom_margin' )) { ?>
.logo-wrapper .logo-image, .logo-wrapper .site-description { margin-bottom: <?php echo of_get_option( 'logo_bottom_margin'); ?>px;}
<?php } ?>

<?php if ( of_get_option( 'menu_top_margin' )) { ?>
.games-menu, .top-bar#top-bar-menu .menu { margin-top: <?php echo of_get_option( 'menu_top_margin'); ?>px;}
<?php } ?>

<?php if ( of_get_option( 'site_header_color' )) { ?>
	.top-bar#top-bar-menu, .top-bar#top-bar-menu .menu li a, .top-bar#top-bar-menu .menu .submenu,
	.top-bar, .top-bar ul {background-color: <?php echo of_get_option( 'site_header_color'); ?>;}
	.top-bar#top-bar-menu .menu li {border-top: 2px solid <?php echo of_get_option( 'site_header_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'menu_link_color' )) { ?>
.top-bar#top-bar-menu .menu .submenu>li a, .top-bar#top-bar-menu li.menu-item a { color: <?php echo of_get_option( 'menu_link_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'menu_link_hover_color' )) { ?>
.top-bar#top-bar-menu li.menu-item a:hover, .top-bar#top-bar-menu .menu .submenu>li a:hover, .top-bar#top-bar-menu .menu li:hover, .top-bar#top-bar-menu li.menu-item.is-active >a { color: <?php echo of_get_option( 'menu_link_hover_color'); ?>;}
.top-bar#top-bar-menu .menu li:hover { border-top: 2px solid <?php echo of_get_option( 'menu_link_hover_color'); ?>;}
.top-bar#top-bar-menu .menu .submenu>li:hover {border-top:0;}
<?php } ?>

<?php if ( of_get_option( 'burger_menu_link_color' )) { ?>
	#nav-toggle span, #nav-toggle span:after, #nav-toggle span:before {background: <?php echo of_get_option( 'burger_menu_link_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'table_header_bg_color' )) { ?>
	.tablepress thead tr th, .vh-casino-providers thead tr th {background-color: <?php echo of_get_option( 'table_header_bg_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'table_header_text_color' )) { ?>
	.tablepress thead tr th, .vh-casino-providers thead tr th {color: <?php echo of_get_option( 'table_header_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'table_odd_row_color' )) { ?>
	tbody tr:nth-child(even), .tablepress .odd td {background: <?php echo of_get_option( 'table_odd_row_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'table_odd_row_text_color' )) { ?>
	tbody tr:nth-child(even), .tablepress .odd td {color: <?php echo of_get_option( 'table_odd_row_text_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'table_even_row_color' )) { ?>
	tbody tr:nth-child(odd), .tablepress .even td {background: <?php echo of_get_option( 'table_even_row_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'table_even_row_text_color' )) { ?>
	tbody tr:nth-child(odd), .tablepress .even td {color: <?php echo of_get_option( 'table_even_row_text_color'); ?>!important;}
<?php } ?>


<?php if ( of_get_option( 'table_button_color' )) { ?>
	.vh-casino-providers tbody tr td.vh-cta-buttons a.vh-playnow, .tablepress tbody tr td a.button, div[class*=sidebar-wrapper-] .textwidget .tablepress tbody tr td a.button, .sidebar-wrapper .textwidget .tablepress tbody tr td a.button, .bonus-table-sidebar tbody tr .column-4 .button {color: <?php echo of_get_option( 'table_button_color'); ?>!important; border: 1px solid <?php echo of_get_option( 'table_button_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'table_button_hover_color' )) { ?>
	.vh-casino-providers tbody tr td.vh-cta-buttons a.vh-playnow:hover, .tablepress tbody tr td a.button:hover, div[class*=sidebar-wrapper-] .textwidget .tablepress tbody tr td a.button:hover, .sidebar-wrapper .textwidget .tablepress tbody tr td a.button:hover, .bonus-table-sidebar tbody tr .column-4 .button:hover {background-color: <?php echo of_get_option( 'table_button_hover_color'); ?>!important; border-color: <?php echo of_get_option( 'table_button_hover_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'table_button_hover_text_color' )) { ?>
	.vh-casino-providers tbody tr td.vh-cta-buttons a.vh-playnow:hover, .tablepress tbody tr td a.button:hover, div[class*=sidebar-wrapper-] .textwidget .tablepress tbody tr td a.button:hover, .sidebar-wrapper .textwidget .tablepress tbody tr td a.button:hover {color: <?php echo of_get_option( 'table_button_hover_text_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'general_button_color' )) { ?>
	.sidebar .button-container .blue,.sidebar-wrapper .button-container .blue, div[class*=sidebar-wrapper-] .button-container .blue,div[class^=sidebar-wrapper-] .button-container .blue, .bonus-table-sidebar .large-cta, .casino-reviews-grid .card .button, .button, .vh-pagination .next, .vh-pagination .prev, .category-label ul li a, .pagination .current, .pagination a:hover, .pagination button:hover, .large-banner .banner-overlay-box .button {background: <?php echo of_get_option( 'general_button_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'general_button_text_color' )) { ?>
	.sidebar .button-container .blue,.sidebar-wrapper .button-container .blue, div[class*=sidebar-wrapper-] .button-container .blue,div[class^=sidebar-wrapper-] .button-container .blue, .bonus-table-sidebar .large-cta, .sidebar-wrapper .button-container .button, .casino-reviews-grid .card .button, .button, .vh-pagination .next, .vh-pagination .prev, .category-label ul li a, .pagination .current, .pagination a:hover, .pagination button:hover, .large-banner .banner-overlay-box .button {color: <?php echo of_get_option( 'general_button_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'general_button_hover_color' )) { ?>
	.button:focus, .button:hover,
	.bonus-table-sidebar .large-cta:hover, .casino-reviews-grid .card:hover .button, .sidebar .button-container .blue:hover, .sidebar-wrapper .button-container .blue:hover, div[class*=sidebar-wrapper-] .button-container .blue:hover, div[class^=sidebar-wrapper-] .button-container .blue:hover, .large-banner .banner-overlay-box .button:hover {background: <?php echo of_get_option( 'general_button_hover_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'general_button_hover_text_color' )) { ?>
	.button:focus, .button:hover,
	.bonus-table-sidebar .large-cta:hover, .casino-reviews-grid .card:hover .button, .sidebar .button-container .blue:hover, .sidebar-wrapper .button-container .blue:hover, div[class*=sidebar-wrapper-] .button-container .blue:hover, div[class^=sidebar-wrapper-] .button-container .blue:hover, .large-banner .banner-overlay-box .button:hover {color: <?php echo of_get_option( 'general_button_hover_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'games_item_bg_color' )) { ?>
	.Widget_vh_recent_games .vh-games-widget-item h3, .Widget_vh_recent_games .vh-games-widget-item, .vh-item .vh-game-title, li.vh-games-widget-item h3 {background: <?php echo of_get_option( 'games_item_bg_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'games_item_text_color' )) { ?>
	.Widget_vh_recent_games .vh-games-widget-item h3, .Widget_vh_recent_games .vh-games-widget-item, .vh-item .vh-game-title, li.vh-games-widget-item h3 {color: <?php echo of_get_option( 'games_item_text_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'games_btn_color' )) { ?>
	.vh-item .play-now {background: <?php echo of_get_option( 'games_btn_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'games_btn_text_color' )) { ?>
	.vh-item .play-now {color: <?php echo of_get_option( 'games_btn_text_color'); ?>;}
<?php } ?>


<?php if ( of_get_option( 'casino_card_bg_color' )) { ?>
	.casino-reviews-grid .card {background: <?php echo of_get_option( 'casino_card_bg_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'casino_card_text_color' )) { ?>
	.casino-reviews-grid .card, .casino-reviews-grid .card .vh-bonus-text, .casino-reviews-grid .card .terms-link {color: <?php echo of_get_option( 'casino_card_text_color'); ?>!important;}
<?php } ?>

<?php if ( of_get_option( 'casino_card_title_color' )) { ?>
	.casino-reviews-grid .card .vh-casino-title {color: <?php echo of_get_option( 'casino_card_title_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_text_color' )) { ?>
	a, ol, p, ul, dl {color: <?php echo of_get_option( 'content_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_link_color' )) { ?>
	a, .widget ul li a {color: <?php echo of_get_option( 'content_link_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_link_hover_color' )) { ?>
	a:hover, a:focus, .widget ul li a:hover {color: <?php echo of_get_option( 'content_link_hover_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_headers_color' )) { ?>
	h1, h2, h3, h4, h1 a, h2 a, h3 a, h4 a, .page-title, .single-title, .list-post h3 {color: <?php echo of_get_option( 'content_headers_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_meta_color' )) { ?>
	blockquote, blockquote p, h3.comment-reply-title, .byline, .byline .tags-title, .tags, .tags .tags-title, .list-post .read-more, .post-details, .post-details a, .byline a, .tags a, .comment-author a, #comments a {color: <?php echo of_get_option( 'content_meta_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_bannerstrip_bg_color' )) { ?>
	.game-post-banner {background: <?php echo of_get_option( 'content_bannerstrip_bg_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'content_bannerstrip_text_color' )) { ?>
	.game-post-banner h1, .game-post-banner h2 {color: <?php echo of_get_option( 'content_bannerstrip_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'footer_bg_color' )) { ?>
	.footer {background: <?php echo of_get_option( 'footer_bg_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'footer_text_color' )) { ?>
	.footer p, .footer .widget .textwidget, .footer .widget ul li, .footer .widget h2 {color: <?php echo of_get_option( 'footer_text_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'footer_link_color' )) { ?>
	.footer .widget ul li a, .footer p a, .footer .textwidget p a {color: <?php echo of_get_option( 'footer_link_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'footer_strip_color' )) { ?>
	.footer .footer-strip, .top-strip, .top-strip .top-bar, .footer .footer-strip ul.menu li a, .footer .social-icons li a {background: <?php echo of_get_option( 'footer_strip_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'footer_strip_link_color' )) { ?>
	.footer .footer-strip ul.menu li a, .footer .social-icons li a {color: <?php echo of_get_option( 'footer_strip_link_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'top_strip_color' )) { ?>
	.top-strip, .top-strip .top-bar {background: <?php echo of_get_option( 'top_strip_color'); ?>;}
<?php } ?>

<?php if ( of_get_option( 'top_strip_link_color' )) { ?>
	.top-strip .top-bar .top-bar-left ul li a, .top-strip .top-bar ul li a {color: <?php echo of_get_option( 'top_strip_link_color'); ?>;}
<?php } ?>

<?php if (of_get_option('sticky_mobile_affiliate_link_checkbox')) { ?>
	@media (max-width: 768px) {
		.single-vegashero_games .footer {
		    padding-bottom: 3.5rem;
		}
	}
<?php } ?>

<?php if (of_get_option('sticky_mobile_casino_link_checkbox')) { ?>
	@media (max-width: 768px) {
		.single-casino_type .footer {
		    padding-bottom: 3.5rem;
		}
	}
<?php } ?>

<?php if ( of_get_option( 'review_stars_bg_color' )) { ?>
	.review-result-wrapper i {
	    color: <?php echo of_get_option( 'review_stars_bg_color'); ?>!important;
	}
<?php } ?>

<?php if ( of_get_option( 'review_stars_color' )) { ?>
	.review-result i {
		color: <?php echo of_get_option( 'review_stars_color'); ?>!important;
	}
<?php } ?>

<?php

$css = ob_get_clean();
return $css;
}

function theme_enqueue_styles() {
  wp_enqueue_style( 'theme-styles', get_stylesheet_uri() );
  $custom_css = theme_get_custom_css();
  wp_add_inline_style( 'theme-styles', $custom_css );
}

add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 9999 );

