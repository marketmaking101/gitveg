<?php

function game_sidebar() {
	include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	$shortcode_file = WP_PLUGIN_DIR . '/tablepress/classes/class-render.php';
	if (is_plugin_active('tablepress/tablepress.php')) {
		if (class_exists('TablePress_Render')) {
			$table_shortcode = new TablePress_Render();
			$post_id = get_the_ID();
			if (is_singular('vegashero_games')) {
				if (of_get_option('bonus_table')) {
					$bonus_table = of_get_option('bonus_table');
					$play_now_text = of_get_option('play_now_text', 'Play for real');
						echo "<div class='bonus-table-sidebar'>";
						?>
						<a class="large-cta button" id="play-mini-table"><?=$play_now_text?><i></i></a>
						<div id="mini-casino-table">
					<?php
						echo do_shortcode($bonus_table);
						echo "</div>";
						echo "</div>";
					}
				}
			}
	}
}


?>
