<input name="<?=esc_attr($id)?>" id="<?=esc_attr($id)?>" type='number' min='1' step='1' value='<?=esc_attr(get_option($id)?get_option($id):20)?>' />
<p class='description'><?= wp_strip_all_tags(__("If your lobby is showing in 4 columns set the number of games to show to be multiples of 4. For example to display a 4x4 grid of games set the number to 16. Default value is 20.", "vegashero")) ?></p>
