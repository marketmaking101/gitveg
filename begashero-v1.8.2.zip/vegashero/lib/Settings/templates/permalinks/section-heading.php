<div class="error" style="display:block!important;">
    <p class="description"><?= wp_strip_all_tags(__('Changing these settings can break your existing game links. Use these options with care!', 'vegashero')) ?></p>
</div>
<p class="description"><?= wp_strip_all_tags(__('Set URL path settings for the VegasHero games.', 'vegashero')) ?></p>
