<?= get_option($id)?>
