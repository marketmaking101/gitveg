<div class="notice %1$s is-dismissible">
  <p>%2$s</p>
</div>
