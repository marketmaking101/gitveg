<div class="iframe_kh_wrapper">
  <div class="kh-no-close"></div>
    <iframe width="" height="" class="singlegame-iframe" frameborder="0" scrolling="no" allowfullscreen src="%1$s" sandbox="allow-same-origin allow-scripts allow-popups allow-forms"></iframe>
</div>
