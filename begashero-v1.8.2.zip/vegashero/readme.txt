=== VegasHero Casino Affiliate Plugin ===
Contributors: vegashero
Tags: casino,slots,games,arcade,affiliate
Donate link: https://vegashero.co/downloads/vegas-hero-plugin/
Requires at least: 5.0
Tested up to: 6.0.1
Requires PHP: 5.6
Stable tag: 1.8.2
License: GPL2
License URI: https://vegashero.co/licensing-and-terms-of-use/

The VegasHero plugin adds powerful features to your igaming affiliate site. Bulk import free casino & slots games or add your own games manually. Display games in a responsive lobby grid. Easily add and manage your affiliate links through an elegant editable table. Option to customize game titles and content to maximize your SEO.

== Description ==
The VegasHero Casino Affiliate Plugin is a 1-Click solution for any Casino Affiliate that wants reliable demo slot games. Save yourself hundreds of hours of time and effort sourcing and adding demo games to your WordPress site.

COMES WITH A MOBILE RESPONSIVE LOBBY
We added a filterable casino lobby that displays your games in an intuitive nicely laid out grid. The layout is tablet and mobile device friendly.
To make it even cooler we added nice rollover effects to make the user experience slick.

2000+ DEMO CASINO SLOTS
The game selection is continuously being expanded and new slots releases are added regularly. We are now focusing on adding HTML5 slots and mobile friendly games.

ONE-CLICK SETUP
It�s as easy as installing a WordPress plugin. Activate, import games and set your casino affiliate links. Done!

1000+ AFFILIATE CUSTOMERS
Our WordPress Casino Plugin has been implemented on a large number of gambling WordPress affiliate sites. A popular choice of WordPress software whether you are a newbie or an established partner.

SAVE PRECIOUS TIME ADDING GAMES
Sourcing good quality slots images, contacting casino operators to get reliable iframe codes, creating and publishing the posts is all very time-consuming.
The plugin takes care of all this via a quick game import process.

LATEST GAME RELEASES
Fresh game content is important. We do regular game releases following the iGaming software providers hottest free demo slots and casino game titles.

FREE-TO-PLAY CASINO GAMES
Demo games are embed via iframes from game developers or casino operators. All demo casino slots have images loaded from our blazingly fast CDN.

GRID BASED CASINO PAGE
Review casinos in style with a responsive grid card layout. Casino post pages have also been optimized and integrated with a WP-Review.

ADD YOUR OWN CASINO GAMES & CONTENT EASILY
Do you want to add your own iframe codes and build a custom selection of games on your site? We made it easy to add your own games sources, providers or operators. You can customize thumbnail images and game descriptions as you like.

INCLUDE YOUR CASINO AFFILIATE TRACKING
You can insert your casino affiliate tracking links under the games using shortcodes. Every click is tracked back to your affiliate account.

LATEST CASINO GAME RELEASES
Fresh game content is important. We do regular game releases following the software providers hottest free demo slots and casino game titles.

GET THE IGAMING SEO EDGE
Google loves content-rich sites. Add your unique copy to game posts, customize titles and meta info to maximize your SEO.

ANY WORDPRESS THEME
The casino plugin will work with the vast majority of themes. We also recommend our own themes, check out our 100% compatible casino theme or sports betting theme.

== Installation ==
Installation & Games Import
https://vegashero.co/quick-start-guide/

How to Add Your Affiliate Links
https://vegashero.co/vegas-hero-table-shortcode-display-your-own-affiliate-offers-and-links/

== Frequently Asked Questions ==
AM I ABLE TO INSTALL IT MYSELF?
We�ve made the installation process easy, we�ve also made configuration simple and flexible.

CAN I ADD MY AFFILIATE LINKS?
Showing players casino operator offers in a table is often the best converting option. We have a shortcode solution to add your affiliate tracking links under the games.

HOW DO I GET ONGOING GAME UPDATES?
The initial license purchase includes 1 year game updates and premium support. After the 1st year, you can renew with a 50% price reduction to keep receiving the newest slots and casino game releases.

WILL IT WORK WITH MY CURRENT WEBSITE?
The plugin requires WordPress. It also works with multiple third-party plugins you may already use (WP Review, TablePress, All in one SEO) but it can be used without these independently.

CAN I CONTINUE TO USE THE PLUGIN AFTER THE 12-MONTH UPDATES AND SUPPORT EXPIRE?
Yes, you will still be able to use the plugin and the games imported up to that date. You will get new game updates & support as long as you renew annually. We give a large 50% discount on renewal prices.

CAN YOU RECOMMEND A COMPATIBLE CASINO THEME?
Yes, we also sell a 100% compatible themes which you can buy in a bundle with the plugin. Check out our casino and sportsbook theme here: https://vegashero.co/downloads/vegashero-theme/

== Screenshots ==
1. Lobby preview

== Changelog ==
https://vegashero.co/changelog/#vegashero-plugin

== Upgrade Notice ==
Get a license key and add 2000+ games to your website!
The free version of the plugin will let you import 2 games per software provider. To get full access to the game database: purchase a license key here: https://vegashero.co/downloads/vegas-hero-plugin/